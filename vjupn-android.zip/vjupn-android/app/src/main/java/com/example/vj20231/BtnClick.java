package com.example.vj20231;

import android.util.Log;
import android.view.View;

public class BtnClick implements View.OnClickListener {
    @Override
    public void onClick(View view) {
        Log.i("MAIN_APP", "esto es un log");
    }
}
